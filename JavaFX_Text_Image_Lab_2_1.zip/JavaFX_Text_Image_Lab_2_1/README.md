# OOPS Through Java Lab 2.1 — JavaFX Text and Image Display

## AIM
Build a JavaFX GUI that displays the label `Hello, JavaFX!` and an image in an `ImageView`, arranged vertically in a `VBox`.

## Files
- `src/DisplayTextAndImage.java` — JavaFX application
- `src/images/sample-image.png` — sample image loaded by the application

## GUI features
- Window title: `Text and Image Display`
- Label text: `Hello, JavaFX!`
- Image displayed with `ImageView`
- Vertical layout using `VBox`
- Scene size: 600 × 400 pixels

## Run requirements
A JDK and JavaFX SDK must be installed. JavaFX is not included in many modern JDK distributions, so configure the JavaFX SDK in your IDE or use the JavaFX command-line options.

Example command (replace `/path/to/javafx-sdk/lib` with the actual JavaFX SDK `lib` directory):

```bash
javac --module-path /path/to/javafx-sdk/lib --add-modules javafx.controls -d out src/DisplayTextAndImage.java
cp -R src/images out/
java --module-path /path/to/javafx-sdk/lib --add-modules javafx.controls -cp out DisplayTextAndImage
```

The sample image is included in the project, so no extra image download is required.
